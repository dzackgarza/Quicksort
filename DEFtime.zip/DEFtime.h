//
// ============================================================
//
//              TIME
//
// ============================================================
//
//
//      Copyright (C) 1998,1999
//
//                      Assitant Professor David E. Fox
//                      Computer Information Science
//                      American River College
//                      Sacramento, CA  95841
//
//      Permission is granted to use at your own risk and
//      distribute this software in source and binary forms
//      provided the above copyright notice and this paragraph
//      are preserved on all copies.  This software is provided
//      "as is" with no express or implied warranty.
//
//
//  ============================================================
//




// returns time in milliseconds since January 1 1970.
double TIME(void);

